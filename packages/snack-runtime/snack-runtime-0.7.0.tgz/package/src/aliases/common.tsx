import * as AssetRegistry from '../NativeModules/AssetRegistry';
import * as SkiaWeb from '../NativeModules/ReactNativeSkia';

const aliases: { [key: string]: any } = {
  expo: require('expo'),
  react: require('react'),
  'react/jsx-runtime': require('react/jsx-runtime'),

  // Needed for loading assets from packages bundled by snackager
  AssetRegistry,
  '@react-native/assets-registry/registry': AssetRegistry,

  // Packages that require special initialisation (see Modules.tsx)
  'expo-asset': require('expo-asset'),
  'expo-font': require('expo-font'),
  'react-native-gesture-handler': require('react-native-gesture-handler'),
  'react-native-safe-area-context': require('react-native-safe-area-context'),
  'react-native-vector-icons': require('@expo/vector-icons'),
  '@expo/vector-icons': require('@expo/vector-icons'),

  // Snackager can't bundle expo-modules-core, so we vendor it instead
  'expo-modules-core': require('expo-modules-core'),

  // Packages that are used internally by the runtime
  'expo-constants': require('expo-constants'),
  'expo-file-system': require('expo-file-system'),
  // 'expo-updates': require('expo-updates'), TODO: add this back through the new context API
  '@react-native-async-storage/async-storage': require('@react-native-async-storage/async-storage'),

  // Renamed `@react-native-community` packages
  '@react-native-community/async-storage': require('@react-native-async-storage/async-storage'),

  // Common packages that are included for easy of use
  'prop-types': require('prop-types'),

  // Aliases for the image examples in react native docs
  '@expo/snack-static/react-native-logo.png': require('../react-native-logo.png'),

  // Use the fixed react native reanimated shipped in the snack runtime
  // It's a workaround for issues we encountered with the newer babel plugin for SDK 44
  'react-native-reanimated': require('react-native-reanimated'),

  // Used by @shopify/react-native-skia, on web only
  '@shopify/react-native-skia/lib/module/web': SkiaWeb,
};

export default aliases;
